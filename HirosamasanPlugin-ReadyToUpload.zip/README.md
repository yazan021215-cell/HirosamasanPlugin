# HirosamasanPlugin

Starter PvP toggle plugin for Paper 1.21.11.

## Commands
- `/pvp` — toggle your PvP protection.
- `/pvpstatus` — show your PvP setting.

## Build
This repository is configured to build automatically with GitHub Actions when files are pushed to `main`. Open the Actions tab, run **Build HirosamasanPlugin**, then download the `HirosamasanPlugin-JAR` artifact.

Requirements for local building: Java 21 and Gradle 8.14.
