# HirosamasanPlugin

Starter PvP toggle plugin for Paper 1.21.11.

## Features
- `/pvp` toggles your PvP protection.
- `/pvpstatus` reports whether protection is enabled.
- Blocks direct player attacks and player-shot projectiles if either player has protection enabled.
- Broadcasts a configurable message when one player kills another.
- Messages and prefix are editable in `plugins/HirosamasanPlugin/config.yml`.

## Requirements
- Paper 1.21.11
- JDK 21 to build the project
- Gradle, or IntelliJ IDEA with Gradle support

## Build the JAR
1. Open this project folder in IntelliJ IDEA and import it as a Gradle project, or open a terminal in this folder where Gradle is installed.
2. Run `gradle build`.
3. The JAR should be created at `build/libs/HirosamasanPlugin-1.0.0.jar`.
4. Upload the JAR into the Paper server's `plugins` folder.
5. Restart the server fully. Avoid `/reload`.
6. Edit `plugins/HirosamasanPlugin/config.yml` to customize messages.

## Notes
- PvP protection is disabled by default for players; `/pvp` turns protection on or off.
- Protection state is kept in memory and resets after a server restart.
- This plugin is for Paper/Spigot servers, not the Velocity proxy itself.
