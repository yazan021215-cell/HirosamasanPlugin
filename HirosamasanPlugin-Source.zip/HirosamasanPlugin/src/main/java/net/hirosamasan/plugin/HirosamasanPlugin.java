package net.hirosamasan.plugin;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class HirosamasanPlugin extends JavaPlugin implements Listener {
    // PvP protection is off by default. UUIDs in this set have protection enabled.
    private final Set<UUID> protectedPlayers = new HashSet<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("HirosamasanPlugin enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().info("HirosamasanPlugin disabled.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(color("&cOnly players can use this command."));
            return true;
        }

        if (command.getName().equalsIgnoreCase("pvp")) {
            UUID id = player.getUniqueId();
            if (protectedPlayers.remove(id)) {
                sendConfigured(player, "pvp-enabled");
            } else {
                protectedPlayers.add(id);
                sendConfigured(player, "pvp-disabled");
            }
            return true;
        }

        if (command.getName().equalsIgnoreCase("pvpstatus")) {
            sendConfigured(player, protectedPlayers.contains(player.getUniqueId())
                    ? "pvp-status-off" : "pvp-status-on");
            return true;
        }

        return false;
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlayerDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;

        Player attacker = getAttackingPlayer(event);
        if (attacker == null) return;

        if (protectedPlayers.contains(attacker.getUniqueId())) {
            event.setCancelled(true);
            sendConfigured(attacker, "you-pvp-disabled");
            return;
        }

        if (protectedPlayers.contains(victim.getUniqueId())) {
            event.setCancelled(true);
            sendConfigured(attacker, "other-pvp-disabled");
        }
    }

    private Player getAttackingPlayer(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player player) return player;
        if (event.getDamager() instanceof Projectile projectile
                && projectile.getShooter() instanceof Player player) return player;
        return null;
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();
        if (killer == null) return;

        String message = getConfig().getString("messages.player-killed",
                "&e%killer% &7defeated &c%victim%&7!");
        message = message.replace("%killer%", killer.getName())
                .replace("%victim%", victim.getName());
        getServer().broadcastMessage(color(getConfig().getString("prefix", "") + message));
    }

    private void sendConfigured(Player player, String key) {
        String message = getConfig().getString("messages." + key, "&cMissing message: " + key);
        player.sendMessage(color(getConfig().getString("prefix", "") + message));
    }

    private String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text);
    }
}
